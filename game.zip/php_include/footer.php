<footer class="footer-style-one">
   <div class="footer__top-wrap pt-20 pb-[30px] px-0 border-t-[#151d23] border-t border-solid">
      <div class="container">
         <div class="flex flex-wrap mx-[-15px]">
            <div class="w-4/12 basis-4/12 2xl:w-4/12 2xl:basis-4/12 xl:w-4/12 xl:basis-4/12 lg:w-5/12 lg:basis-5/12 md:w-7/12 md:basis-7/12 sm:w-full sm:basis-full xsm:w-full xsm:basis-full relative px-[15px]">
               <div class="footer-widget mt-0 mb-[50px] mx-0 ">
                  <div class="footer-logo logo mt-0 mb-[30px] mx-0">
                     <a href="index-2.html"><img class="max-w-[177px]" src="images/logo.png" alt="Logo"></a>
                  </div>
                  <div class="footer-text mr-[30px] sm:mr-0 xsm:mr-0">
                     <p class="desc text-[15px] mt-0 mb-[25px] mx-0">
Online gaming has evolved into a dynamic and expansive industry, transforming from a niche hobby into a global phenomenon.</p>
                     <p class="social-title text-[16px] font-semibold uppercase text-[#ecebeb] leading-none mt-0 mb-[25px] mx-0">Active <span class=" text-[#45f882]">With Us <i class="fas fa-angle-double-right"></i></span></p>
                     <div class="footer-social flex flex-wrap gap-[10px_20px]">
                        <a class="block" href="#"><img class=" max-w-[30px]" src="assets/img/icons/social_icon01.png" alt="iocn"></a>
                        <a class="block" href="#"><img class=" max-w-[30px]" src="assets/img/icons/social_icon02.png" alt="iocn"></a>
                        <a class="block" href="#"><img class=" max-w-[30px]" src="assets/img/icons/social_icon03.png" alt="iocn"></a>
                        <a class="block" href="#"><img class=" max-w-[30px]" src="assets/img/icons/social_icon04.png" alt="iocn"></a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="w-2/12 basis-2/12 2xl:w-2/12 2xl:basis-2/12 xl:w-2/12 xl:basis-2/12 lg:w-3/12 lg:basis-3/12 md:w-5/12 md:basis-5/12 sm:w-6/12 sm:basis-6/12 xsm:w-full xsm:basis-full relative px-[15px]">
               <div class="footer-widget mt-0 mb-[50px] mx-0  pl-10 widget_nav_menu md:pl-0 sm:pl-0 xsm:pl-0">
                  <h4 class="fw-title  text-[20px] mt-0 mb-7 mx-0 ">quick link</h4>
                  <ul class="list-wrap m-0 p-0  menu">
                     <li class=" mt-0 mb-1.5 mx-0"><a class=" text-[15px] inline-block text-[#adb0bc] relative hover:text-[#45f882]  after:content-[''] after:absolute after:w-full after:h-px after:origin-[right_top] after:transition-transform after:duration-[0.4s] after:ease-[cubic-bezier(0.74,0.72,0.27,0.24)] after:scale-x-0 after:scale-y-100 after:left-0 after:bottom-0 after:bg-[#45f882]  hover:after:origin-[left_top] hover:after:scale-100" href="index.php">Home</a></li>
                     <li class=" mt-0 mb-1.5 mx-0"><a class=" text-[15px] inline-block text-[#adb0bc] relative hover:text-[#45f882]  after:content-[''] after:absolute after:w-full after:h-px after:origin-[right_top] after:transition-transform after:duration-[0.4s] after:ease-[cubic-bezier(0.74,0.72,0.27,0.24)] after:scale-x-0 after:scale-y-100 after:left-0 after:bottom-0 after:bg-[#45f882]  hover:after:origin-[left_top] hover:after:scale-100" href="login.php">Login</a></li>
                     <li class=" mt-0 mb-1.5 mx-0"><a class=" text-[15px] inline-block text-[#adb0bc] relative hover:text-[#45f882]  after:content-[''] after:absolute after:w-full after:h-px after:origin-[right_top] after:transition-transform after:duration-[0.4s] after:ease-[cubic-bezier(0.74,0.72,0.27,0.24)] after:scale-x-0 after:scale-y-100 after:left-0 after:bottom-0 after:bg-[#45f882]  hover:after:origin-[left_top] hover:after:scale-100" href="register.php">Register</a></li>
                     <li class=" mt-0 mb-1.5 mx-0"><a class=" text-[15px] inline-block text-[#adb0bc] relative hover:text-[#45f882]  after:content-[''] after:absolute after:w-full after:h-px after:origin-[right_top] after:transition-transform after:duration-[0.4s] after:ease-[cubic-bezier(0.74,0.72,0.27,0.24)] after:scale-x-0 after:scale-y-100 after:left-0 after:bottom-0 after:bg-[#45f882]  hover:after:origin-[left_top] hover:after:scale-100" href="contact.php">Contact Us</a></li>
                  </ul>
               </div>
            </div>
            <div class="w-2/12 basis-2/12 2xl:w-2/12 2xl:basis-2/12 xl:w-2/12 xl:basis-2/12 lg:w-3/12 lg:basis-3/12 md:w-5/12 md:basis-5/12 sm:w-6/12 sm:basis-6/12 xsm:w-full xsm:basis-full relative px-[15px]">
               <div class="footer-widget mt-0 mb-[50px] mx-0 pl-[50px]  widget_nav_menu md:pl-0 sm:pl-0 xsm:pl-0">
                  <h4 class="fw-title  text-[20px] mt-0 mb-7 mx-0 ">Games</h4>
                  <ul class="list-wrap m-0 p-0  menu">
                     <li class=" mt-0 mb-1.5 mx-0"><a class=" text-[15px] inline-block text-[#adb0bc] relative hover:text-[#45f882]  after:content-[''] after:absolute after:w-full after:h-px after:origin-[right_top] after:transition-transform after:duration-[0.4s] after:ease-[cubic-bezier(0.74,0.72,0.27,0.24)] after:scale-x-0 after:scale-y-100 after:left-0 after:bottom-0 after:bg-[#45f882]  hover:after:origin-[left_top] hover:after:scale-100" href="cricket.php">About Cricket</a></li>
                     <li class=" mt-0 mb-1.5 mx-0"><a class=" text-[15px] inline-block text-[#adb0bc] relative hover:text-[#45f882]  after:content-[''] after:absolute after:w-full after:h-px after:origin-[right_top] after:transition-transform after:duration-[0.4s] after:ease-[cubic-bezier(0.74,0.72,0.27,0.24)] after:scale-x-0 after:scale-y-100 after:left-0 after:bottom-0 after:bg-[#45f882]  hover:after:origin-[left_top] hover:after:scale-100" href="rummy.php">About Rummy</a></li>
                     <li class=" mt-0 mb-1.5 mx-0"><a class=" text-[15px] inline-block text-[#adb0bc] relative hover:text-[#45f882]  after:content-[''] after:absolute after:w-full after:h-px after:origin-[right_top] after:transition-transform after:duration-[0.4s] after:ease-[cubic-bezier(0.74,0.72,0.27,0.24)] after:scale-x-0 after:scale-y-100 after:left-0 after:bottom-0 after:bg-[#45f882]  hover:after:origin-[left_top] hover:after:scale-100" href="matka.php">About Matka</a></li>
                     <li class=" mt-0 mb-1.5 mx-0"><a class=" text-[15px] inline-block text-[#adb0bc] relative hover:text-[#45f882]  after:content-[''] after:absolute after:w-full after:h-px after:origin-[right_top] after:transition-transform after:duration-[0.4s] after:ease-[cubic-bezier(0.74,0.72,0.27,0.24)] after:scale-x-0 after:scale-y-100 after:left-0 after:bottom-0 after:bg-[#45f882]  hover:after:origin-[left_top] hover:after:scale-100" href="volleyball.php">About Volleyball</a></li>
                  </ul>
               </div>
            </div>
            <div class="w-4/12 basis-4/12 2xl:w-4/12 2xl:basis-4/12 xl:w-4/12 xl:basis-4/12 lg:w-5/12 lg:basis-5/12 md:w-7/12 md:basis-7/12 sm:w-full sm:basis-full xsm:w-full xsm:basis-full relative px-[15px]">
               <div class="footer-widget mt-0 mb-[50px] mx-0 pl-[78px] lg:pl-[0] md:pl-0 sm:pl-0 xsm:pl-0">
                  <h4 class="fw-title  text-[20px] mt-0 mb-7 mx-0 ">Newsletter</h4>
                  <div class="footer-newsletter">
                     <p class=" text-[15px] mt-0 mb-[25px] mx-0">Subscribe our newsletter to get our latest update & newsconsectetur</p>
                     <form action="#" class="footer-newsletter-form relative">
                        <input type="email" placeholder="Your email address" class=" block w-full text-[14px] h-[60px] pl-[25px] pr-[100px] py-[17px] rounded-md border-none bg-[#1f2935] placeholder:text-[14px] focus:ring-[none] focus:!border-none ">
                        <button type="submit" class=" absolute w-[63px] h-full text-[28px] text-[#1f2935] flex items-center justify-center p-2.5 rounded-md border-[none] right-0 top-0 bg-[#45f882] hover:bg-[#ffbe18] "><i class="flaticon-paper-plane"></i></button>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="copyright__wrap px-0 py-5 bg-[#090d10]">
      <div class="container">
         <div class="flex flex-wrap mx-[-15px]  items-center ">
            <div class="w-7/12 basis-7/12 2xl:w-7/12 2xl:basis-7/12 xl:w-7/12 xl:basis-7/12 lg:w-7/12 lg:basis-7/12 md:w-7/12 md:basis-7/12 sm:w-full sm:basis-full xsm:w-full xsm:basis-full relative px-[15px]">
               <div class="copyright__text text-left sm:text-center xsm:text-center">
                  <p class=" text-[14px] font-semibold uppercase text-[#9f9f9f] m-0 font-Barlow">Copyright © 2024 - All Rights Reserved By <span class=" text-[#45f882]">Speed Bet</span></p>
               </div>
            </div>
            <div class="w-5/12 basis-5/12 2xl:w-5/12 2xl:basis-5/12 xl:w-5/12 xl:basis-5/12 lg:w-5/12 lg:basis-5/12 md:w-5/12 md:basis-5/12 sm:w-full sm:basis-full xsm:w-full xsm:basis-full relative px-[15px]">
               <div class="copyright__card float-right sm:float-none sm:text-center sm:mt-[10px] sm:m-[0_auto] xsm:float-none xsm:text-center xsm:mt-[10px] xsm:m-[0_auto]">
                  <img class="sm:inline-block xsm:inline-block" src="assets/img/others/payment_card.png" alt="img">
               </div>
            </div>
         </div>
      </div>
   </div>
</footer>
