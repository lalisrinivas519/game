<?php

 $con=mysqli_connect("localhost", "root", "", "games");

if (mysqli_connect_error()) {
	echo "Connection Error.";
} else {
	
	
}
?>